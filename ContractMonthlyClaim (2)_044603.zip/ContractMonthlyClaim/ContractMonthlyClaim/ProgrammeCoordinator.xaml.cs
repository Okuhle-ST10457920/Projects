﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Microsoft.Data.SqlClient;
using System.Windows;
using Microsoft.VisualBasic;

namespace ContractMonthlyClaim
{
    /// <summary>
    /// Interaction logic for ProgrammeCoordinator.xaml
    /// </summary>
    public partial class ProgrammeCoordinator : Window
    {
        private readonly string sqlConnection = "Data Source=LAPTOP-CONRE6DS\\SQLEXPRESS;Initial Catalog=CONTRACT_MONTHLY_CLAIM;Integrated Security=True;Trust Server Certificate=True";

        public ProgrammeCoordinator()
        {
            InitializeComponent();
        }

        private void Return_Click(object sender, RoutedEventArgs e)
        {
            MainWindow window = new MainWindow();
            window.WindowState = WindowState.Maximized;
            window.Show();
            this.Close();
        }

        private void View_Lecturer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();

                    string query = "SELECT * FROM ClaimLecturer;";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            DataTable table = new DataTable();
                            table.Load(reader);

                            if (table.Rows.Count == 0)
                            {
                                MessageBox.Show("No data found.", "View", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                string? output = "";
                                foreach (DataRow row in table.Rows)
                                {
                                    foreach (DataColumn column in table.Columns)
                                    {
                                        output += $"{column.ColumnName}: {row[column]}\n";
                                    }
                                    MessageBox.Show(output, "View", MessageBoxButton.OK, MessageBoxImage.Information);
                                    output = null;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when viewing lecturer information: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void View_Claims_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();

                    string query = "SELECT Claims.ClaimID, ClaimLecturer.Name, Claims.ClaimAmount, Claims.ClaimDate FROM ClaimLecturer INNER JOIN Claims ON ClaimLecturer.LecturerID = Claims.LecturerID GROUP BY Claims.ClaimID, ClaimLecturer.Name, Claims.ClaimAmount, Claims.ClaimDate;";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            DataTable table = new DataTable();
                            table.Load(reader);

                            if (table.Rows.Count == 0)
                            {
                                MessageBox.Show("No data found.", "View", MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            else
                            {
                                string? output = "";
                                foreach (DataRow row in table.Rows)
                                {
                                    foreach (DataColumn column in table.Columns)
                                    {
                                        output += $"{column.ColumnName}: {row[column]}\n";
                                    }
                                    MessageBox.Show(output, "View", MessageBoxButton.OK, MessageBoxImage.Information);
                                    output = null;
                                }
                            }
                        }
                    }

                    string claimID = Interaction.InputBox("Enter the claim ID you want to delete.", "Delete claim");

                    string secQuery = "DELETE FROM Claims WHERE Claims.ClaimID = @ClaimID;";

                    using (SqlCommand secCommand = new SqlCommand(secQuery, connection))
                    {
                        secCommand.Parameters.AddWithValue("@ClaimID", claimID);

                        int rowsAffected = secCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data deleted successfully", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("No data found.", "Manage Claims", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error when viewing claims: {ex.Message}", "Error message", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
        }

        private void Process_Click(object sender, RoutedEventArgs e)
        {
            AcademicManager manager = new AcademicManager();
            manager.ProcessClaim();
            MessageBox.Show("Sent successfully", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
