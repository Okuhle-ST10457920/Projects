﻿using NAudio.Wave;

namespace Prog_Part_1
{
    public class ChatBot
    {
        // Created variables that will hold the name of the user and the chatbot
        private string userName="", chatBotName="";
        
        // This method will output the voice message of a woman welcoming the user
        public void Voice_Greeting()
        {
            try
            {
                using (var audioFilePath = new AudioFileReader(@"C:\\Users\\Okuhle mkhutshulwa\\New folder (2)\\VoiceGreeting.mp3"))
                using (var outputDevice = new WaveOutEvent())
                {
                    outputDevice.Init(audioFilePath);
                    outputDevice.Play();
                    while (outputDevice.PlaybackState == PlaybackState.Playing)
                    {
                        Thread.Sleep(1000);
                    }
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Audio file not found.");
            }
            catch (FormatException) 
            {
                Console.WriteLine("Invalid audio file format.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: "+ex.Message);
            }
        }

        // This method will display the ASCII art 
        public void ASCII_Display()
        {
            try
            {
                Console.WriteLine("/██████████\\    \r\n /███░░░░░░░░██\\  \r\n|███░░░░░░░░░░░░█|  \r\n|██░░░░░░░░░░░░░█| \r\n \\██░░░░░░░░░░░░██/  \r\n  \\████░░░░░░░░░██/  \r\n   [███  HACKER  ███]  \r\n   [███  DETECTED ██]  \r\n   [███  SYSTEM ███]  \r\n   [███  SECURE ██]\r\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }

        // This method will greet the user with text and an ASCII art
        public void Text_Greeting()
        {
            chatBotName = "ChatBot";
            try
            {
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: Hey my name is Chatbot, what's yours? \nUser: ", 50);
                Console.ResetColor();
                userName = Console.ReadLine();
                Delay(1000);
                TypeEffect($"\n██████╗██╗   ██╗██████╗ ███████╗███████╗██████╗ ██╗   ██╗\r\n  ██╔════╝██║   ██║██╔══██╗██╔════╝██╔════╝██╔══██╗╚██╗ ██╔╝\r\n  ██║     ██║   ██║██████╔╝█████╗  █████╗  ██████╔╝ ╚████╔╝ \r\n  ██║     ██║   ██║██╔═══╝ ██╔══╝  ██╔══╝  ██╔═══╝   ╚██╔╝  \r\n  ╚██████╗╚██████╔╝██║     ███████╗███████╗██║        ██║   \r\n   ╚═════╝ ╚═════╝ ╚═╝     ╚══════╝╚══════╝╚═╝        ╚═╝   \r\n   \r\n   [ WELCOME TO CYBER SECURITY SYSTEM ]  \r\n   [ █▓▒░ AUTHORIZED ACCESS ONLY ░▒▓█ ]  \r\n   [ █▓▒░ SYSTEM MONITORING ACTIVATED... ░▒▓█ ]  \r\n   \r\n   LOADING SECURITY PROTOCOLS... ████████░░░░░░ 60%  \r\n   INITIATING FIREWALL DEFENSE... ██████████░░ 80%  \r\n   ENCRYPTING CONNECTIONS... ████████████ 100% ✅  \r\n   \r\n   [ █▓▒░ ACCESS GRANTED ░▒▓█ ]  \r\n   >>_\n", 10);
                Console.ForegroundColor = ConsoleColor.Red;
                Delay(1000);
                TypeEffect($"{chatBotName}: Nice to meet you {userName}, I hope you are enjoying your day.\n\n", 50);
                Console.ResetColor();
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message); 
            }
        }

        // This method is where the user interacts with the chatbot in a conversion
        public void Basic_Response_System()
        {
            try
            {
                Delay(1000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: ...Í'm sure you have questions you would like to ask so ask away :), \nIf you don't just type exit :( \n{userName}: ", 50);
                Console.ResetColor ();
                string response = Console.ReadLine();
                string answer = response.ToLower();

                while (!answer.Equals("exit")) 
                {
                    if (answer.Contains("how are you"))
                    {
                        Delay(1000);
                        Console.ForegroundColor = ConsoleColor.Red;
                        TypeEffect($"{chatBotName}: I'm feeling good even though i'm a chatbot with no feelings whatsoever, how are you feeling?\n{userName}: ", 50);
                        Console.ResetColor();
                        answer = Console.ReadLine();

                        if (answer.Contains("good") || answer.Contains("great") || answer.Contains("alright") || answer.Contains("okay") || answer.Contains("fine") || answer.Contains("sharp") || answer.Contains("calm") || answer.Contains("relax"))
                        {
                            Delay(1000);
                            Console.ForegroundColor = ConsoleColor.Red;
                            TypeEffect($"{chatBotName}: That's good to hear.", 50);
                            Delay(1000);
                            TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                            Console.ResetColor();
                            answer = Console.ReadLine();
                        }
                        else
                        {
                            Delay(1000); 
                            Console.ForegroundColor = ConsoleColor.Red;
                            TypeEffect($"{chatBotName}: Try to be positve because tommorrow is another day, stay calm and move on:)", 50);
                            Delay(1000);
                            TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                            Console.ResetColor();
                            answer = Console.ReadLine();

                        }
                    }
                    else if (answer.Contains("purpose"))
                    {
                        Delay(1000);
                        Console.ForegroundColor = ConsoleColor.Red;
                        TypeEffect($"\n{chatBotName}: My purpose is to provide you with information regarding" +
                            " cybersecurity to help you better understand how to protect yourself " +
                            "from unwanted threats or anything that will harm your personal data or " +
                            "devices.", 50);
                        Delay(1000);
                        TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                        Console.ResetColor();
                        answer = Console.ReadLine();
                    }
                    else if (answer.Contains("ask"))
                    {
                        Delay(1000);
                        Console.ForegroundColor = ConsoleColor.Red;
                        TypeEffect($"{chatBotName}: You can ask anything that is cybersecurity related like password safety, phishing and safe browsing. You can choose 1 topic. \n{userName}: ", 50);
                        Console.ResetColor();
                        response = Console.ReadLine();
                        Console.WriteLine();

                        if (response.Contains("password safety"))
                        {
                            Delay(2000);
                            Console.ForegroundColor = ConsoleColor.Red;
                            TypeEffect($"{chatBotName}:\n\nPassword Safety" +
                                "\n----------------\n", 10);
                            TypeEffect("Password safety refers to the practices and measures taken to protect " +
                                "passwords from unauthorized access, use, or compromise. Here are some key aspects of password safety: " +
                                "\n\nBEST PRACTICE FOR PASSWORD SAFETY" +
                                "\nUse strong and unique passwords: Use a combination of uppercase and lowercase letters, " +
                                "numbers, and special characters to create a strong password. Avoid using easily guessable " +
                                "information such as your name, birthdate, or common words.", 10);
                            TypeEffect("\n\nPASSWORD SAFETY TIPS" +
                                "\nDon't share your passwords: Avoid sharing your passwords with " +
                                "others, including friends and family members.", 10);
                            TypeEffect("\n\nPASSWORD SAFETY TOOLS" +
                                "\nTwo-factor authetication apps: Consider using a 2FA app, such as " +
                                "Google Authenticator or Authy, to generate time-based one-time passwords(TOTPs) for your accounts.\n", 10);
                            Delay(1000);
                            TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                            Console.ResetColor();
                            answer = Console.ReadLine();
                        }
                        else if (response.Contains("phishing"))
                        {
                            Delay(2000);
                            Console.ForegroundColor = ConsoleColor.Red;
                            TypeEffect($"{chatBotName}:\n\nPhishing" +
                                "\n---------\n", 10);
                            TypeEffect("Phishing is a type of cybercrime where attackers use fraudulent emails, " +
                                "texts, or messages to trick victims into revealing sensitive information, such as passwords, " +
                                "credit card numbers, or other personal data. " +
                                "\n\nTYPES OF PHISHING ATTACKS" +
                                "\nEmail Phishing: The most common type of phishing attack, where attackers send fake emails " +
                                "that appear to be from a legitimate source, such as a bank or online retailer." +
                                "\nSpear Phishing: A targeted phishing attack where attackers focus on a specific individual " +
                                "or group, often using personalized information to make the attack more convincing.", 10);
                            TypeEffect("\n\nPHISHING TECHNIQUES" +
                                "\nSpoofing: Attackers create fake emails or websites that appear to be from a " +
                                "legitimate source." +
                                "\nBaiting: Attackers offer victims a tempting offer or reward in exchange for sensitive information.", 10);
                            TypeEffect("\n\nHOW TO PROTECT YOURSELF FROM PHISHING ATTACKS" +
                                "\nBe cautius of suspicious emails or messages: If an email or message looks suspicious or asks for " +
                                "sensitive information, do not respond or click on any links.", 10);
                            TypeEffect("\n\nWHAT TO DO IF YOU FALL VICTIM TO A PHISHING ATTACK" +
                                "\nChange your passwords: Immediately change your passwords for all accounts that may have been compromised.\n", 10);
                            Delay(1000);
                            TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                            Console.ResetColor();
                            answer = Console.ReadLine();
                        }
                        else if (response.Contains("safe browsing"))
                        {
                            Delay(2000);
                            Console.ForegroundColor = ConsoleColor.Red;
                            TypeEffect($"{chatBotName}:\n\nSafe Browsing" +
                                "\n--------------\n", 10);
                            TypeEffect("Safe browsing refers to the practice of using the internet in a way that protects your " +
                                "personal information, devices, and online idenity from potential threats and risks. Here are some " +
                                "key aspects of safe browsing: ", 10);
                            TypeEffect("\n\nSAFE BROWSING PRACTICES" +
                                "\nUse a secure connection: Make sure the websites you visit use HTTPS(Hypertext Transfer Protocol Secure) " +
                                "instead of HTTP.This ensures that the data you exchange with the website is encrypted." +
                                "\nKeep your browser and software up to date: Regularly update your browser, operating system, and " +
                                "other software to ensureyou have the latest security patches and features.", 10);
                            TypeEffect("\n\nSAFE BROWSING TOOLS" +
                                "\nBrowser extensions: Use browser extensions like uBlock Origin, HTTPS Everywhere, and LastPass " +
                                "to enhance your online security and privacy.", 10);
                            TypeEffect("\n\nSAFE BROWSING TIPS" +
                                "\nBe aware of phishing scams: Be cautious of emails or messages that ask for personal information " +
                                "or direct you to suspicious websites.\n", 10);
                            Delay(1000);
                            TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                            Console.ResetColor();
                            answer = Console.ReadLine();
                        }
                        else
                        {
                            Delay(1000);
                            Console.ForegroundColor = ConsoleColor.Red;
                            TypeEffect($"{chatBotName}: I didn't quite understand that. Could you rephrase?\n{userName}: ", 50);
                            Console.ResetColor();
                            response = Console.ReadLine();
                        }
                    }
                    else
                    {
                        Delay(1000);
                        Console.ForegroundColor = ConsoleColor.Red;
                        TypeEffect($"{chatBotName}: I didn't quite understand that. Could you rephrase?\n{userName}: ", 50);
                        Console.ResetColor();
                        answer = Console.ReadLine();
                    }
                }
            }
            catch (Exception ex)
            {
                Delay(1000);
                TypeEffect($"{chatBotName}: {ex.Message}", 50);
            }
        }

        private static void Delay(int milliseconds)
        {
            DateTime start = DateTime.Now;
            while ((DateTime.Now - start).TotalMilliseconds < milliseconds) ;
        }

        private static void TypeEffect(string text, int delay)
        {
            foreach (char c in text)
            { 
                Console.Write(c);
                Thread.Sleep(delay);
            }
        }
    }
}
