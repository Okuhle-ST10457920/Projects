﻿using Prog_Part_1;

class Program
{
    // This main method will call and run the methods in the Chatbot class
    static void Main()
    {
        ChatBot chatBot = new ChatBot();

        chatBot.Voice_Greeting();
        chatBot.ASCII_Display();
        chatBot.Text_Greeting();
        chatBot.Basic_Response_System();
    }
}