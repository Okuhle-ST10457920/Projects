﻿using NAudio.Wave;

namespace Prog_Part_1
{
    public class ChatBot
    {
        // Created variables that holds the favourite topic of the user, name of the user and the chatbot
        private string chatBotName = "ChatBot", userName ="",  favouriteTopic="";
        
        // This method will output the voice message of a woman welcoming the user
        public void Voice_Greeting()
        {
            try
            {
                using (var audioFilePath = new AudioFileReader(@"C:\\Users\\Okuhle mkhutshulwa\\New folder (2)\\VoiceGreeting.mp3"))
                using (var outputDevice = new WaveOutEvent())
                {
                    outputDevice.Init(audioFilePath);
                    outputDevice.Play();
                    while (outputDevice.PlaybackState == PlaybackState.Playing)
                    {
                        Thread.Sleep(1000);
                    }
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Audio file not found.");
            }
            catch (FormatException) 
            {
                Console.WriteLine("Invalid audio file format.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: "+ex.Message);
            }
        }

        // This method will display the ASCII art 
        public void ASCII_Display()
        {
            try
            {
                Console.WriteLine("/██████████\\    \r\n /███░░░░░░░░██\\  \r\n|███░░░░░░░░░░░░█|  \r\n|██░░░░░░░░░░░░░█| \r\n \\██░░░░░░░░░░░░██/  \r\n  \\████░░░░░░░░░██/  \r\n   [███  HACKER  ███]  \r\n   [███  DETECTED ██]  \r\n   [███  SYSTEM ███]  \r\n   [███  SECURE ██]\r\n");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }

        // This method will greet the user with text and an ASCII art
        public void Text_Greeting()
        {
            try
            {
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: Hey my name is Chatbot, what's yours? \nUser: ", 50);
                Console.ResetColor();
                userName = Console.ReadLine();
                Delay(1000);
                TypeEffect($"\n██████╗██╗   ██╗██████╗ ███████╗███████╗██████╗ ██╗   ██╗\r\n  ██╔════╝██║   ██║██╔══██╗██╔════╝██╔════╝██╔══██╗╚██╗ ██╔╝\r\n  ██║     ██║   ██║██████╔╝█████╗  █████╗  ██████╔╝ ╚████╔╝ \r\n  ██║     ██║   ██║██╔═══╝ ██╔══╝  ██╔══╝  ██╔═══╝   ╚██╔╝  \r\n  ╚██████╗╚██████╔╝██║     ███████╗███████╗██║        ██║   \r\n   ╚═════╝ ╚═════╝ ╚═╝     ╚══════╝╚══════╝╚═╝        ╚═╝   \r\n   \r\n   [ WELCOME TO CYBER SECURITY SYSTEM ]  \r\n   [ █▓▒░ AUTHORIZED ACCESS ONLY ░▒▓█ ]  \r\n   [ █▓▒░ SYSTEM MONITORING ACTIVATED... ░▒▓█ ]  \r\n   \r\n   LOADING SECURITY PROTOCOLS... ████████░░░░░░ 60%  \r\n   INITIATING FIREWALL DEFENSE... ██████████░░ 80%  \r\n   ENCRYPTING CONNECTIONS... ████████████ 100% ✅  \r\n   \r\n   [ █▓▒░ ACCESS GRANTED ░▒▓█ ]  \r\n   >>_\n", 10);
                Console.ForegroundColor = ConsoleColor.Red;
                Delay(1000);
                TypeEffect($"{chatBotName}: Nice to meet you {userName}, I hope you are enjoying your day.\n\n", 50);
                Console.ResetColor();
            }
            catch (Exception ex) 
            {
                Console.WriteLine(ex.Message); 
            }
        }

        // This method is where the user interacts with the chatbot in a conversion
        public void Response_System()
        {
            try
            {
                Delay(1000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: ...Í'm sure you have questions you would like to ask so ask away :), \nIf you don't just type exit :( \n{userName}: ", 50);
                Console.ResetColor();
                string response = Console.ReadLine();
                string answer = response.ToLower();

                string phishing = "phishing", virus = "virus", worm = "worm", trojan = "trojan", authentication = "two-factor authentication", firewall = "firewall", phishingEmail = "phishing email", ciaTriad = "cia triad", privacy = "privacy", scam = "scam";

                // Declaring and instatiating the values of the list in a Dictionary
                Dictionary<string, List<string>> randomResponses = new Dictionary<string, List<string>>();
                randomResponses[phishing] = new List<string>();
                randomResponses[virus] = new List<string>();
                randomResponses[worm] = new List<string>();
                randomResponses[trojan] = new List<string>();
                randomResponses[authentication] = new List<string>();
                randomResponses[firewall] = new List<string>();
                randomResponses[phishingEmail] = new List<string>();
                randomResponses[ciaTriad] = new List<string>();
                randomResponses[privacy] = new List<string>();

                Dictionary<string, List<string>> examples = new Dictionary<string, List<string>>();
                examples[phishing] = new List<string>();
                examples[virus] = new List<string>();
                examples[worm] = new List<string>();
                examples[trojan] = new List<string>();
                examples[authentication] = new List<string>();
                examples[firewall] = new List<string>();
                examples[phishingEmail] = new List<string>();
                examples[ciaTriad] = new List<string>();
                examples[privacy] = new List<string>();

                Dictionary<string, List<string>> extraInfo = new Dictionary<string, List<string>>();
                extraInfo[phishing] = new List<string>();
                extraInfo[virus] = new List<string>();
                extraInfo[worm] = new List<string>();
                extraInfo[trojan] = new List<string>();
                extraInfo[authentication] = new List<string>();
                extraInfo[firewall] = new List<string>();
                extraInfo[phishingEmail] = new List<string>();
                extraInfo[ciaTriad] = new List<string>();
                extraInfo[privacy] = new List<string>();

                Dictionary<string, List<string>> sentimentResponse = new Dictionary<string, List<string>>();
                sentimentResponse[phishing] = new List<string>();
                sentimentResponse[virus] = new List<string>();
                sentimentResponse[worm] = new List<string>();
                sentimentResponse[trojan] = new List<string>();
                sentimentResponse[phishingEmail] = new List<string>();
                sentimentResponse[scam] = new List<string>();

                Dictionary<string, List<string>> curiousResponse = new Dictionary<string, List<string>>();
                curiousResponse[phishing] = new List<string>();
                curiousResponse[virus] = new List<string>();
                curiousResponse[worm] = new List<string>();
                curiousResponse[trojan] = new List<string>();
                curiousResponse[phishingEmail] = new List<string>();
                curiousResponse[scam] = new List<string>();

                randomResponses[phishing].Add("Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations.");
                randomResponses[phishing].Add("Don't share personal info. Legitimate companies will never ask for passwords, PINs, or credit card numbers via email or SMS.");
                randomResponses[phishing].Add("Verify directly. If you're unsure about a message, contact the company or person directly using official contact details.");
                randomResponses[phishing].Add("Always verify email senders and never click suspicious links or attachments.");
               
                randomResponses[virus].Add("Keep your operating system and software up-to-date.");
                randomResponses[virus].Add("Use antivirus software.");
                randomResponses[virus].Add("Be cautious with emails and attachments.");
                randomResponses[virus].Add("Use strong passwords and enable two-factor authentication.");
                
                randomResponses[worm].Add("Use a firewall.");
                randomResponses[worm].Add("Keep your operating system and software up-to-date.");
                randomResponses[worm].Add("Use antivirus software.");
                randomResponses[worm].Add("Avoid suspicious downloads or attachments.");
                
                randomResponses[trojan].Add("Download software from trusted sources.");
                randomResponses[trojan].Add("Use antivirus software.");
                randomResponses[trojan].Add("Be cautious with email attachments and links.");
                randomResponses[trojan].Add("Keep your operating system and software up-to-date.");
               
                randomResponses[authentication].Add("It's a security process requiring two different types of verification, like a pasword and a code sent to your phone.");
                randomResponses[authentication].Add("It helps protect accounts even if your password is stolen");
                randomResponses[authentication].Add("Two-factor authentication come in a form of SMS codes, authenticator apps, or biometric data.");
                randomResponses[authentication].Add("Always enable 2FA where available, using an authenticator app rather SMS if possible.");
                
                randomResponses[firewall].Add("It monitors and controls incoming/outgoing network traffic based on security rules.");
                randomResponses[firewall].Add("It acts as a barrier between a trusted internal network and an untrusted external one.");
                randomResponses[firewall].Add("A firewall can be hardware-based, software-based, or even both.");
                randomResponses[firewall].Add("It blocks unauthorized access");
                
                randomResponses[phishingEmail].Add("Be cautious with suspicious emails.");
                randomResponses[phishingEmail].Add("Verify the sender's identity.");
                randomResponses[phishingEmail].Add("Don't click on suspicious links");
                randomResponses[phishingEmail].Add("Don't provide sensitive information.");
                
                randomResponses[ciaTriad].Add("Confidentiality ensures only authorized people can access data.");
                randomResponses[ciaTriad].Add("Integrity ensures data is accurate and hasn't been tampered with.");
                randomResponses[ciaTriad].Add("Availabilty ensures systems and data are accessible when needed.");
                randomResponses[ciaTriad].Add("Use strong passwords and multi-factor authentication (MFA).");

                randomResponses[privacy].Add("Use strong and unique passwords, enable two-factor authentication, be cautious with social media, use a VPN, review app permissions, use private browsing modes and keep your software up-to-date.");
                randomResponses[privacy].Add("Use a different, complex password for each account. Consider using a password manager to keep track of them securely.");
                randomResponses[privacy].Add("Avoid oversharing personal details like your full birthdate, home address, or phone number on social media or unsecured websites.");
                randomResponses[privacy].Add("Add an extra layer of security to your accounts by enabling 2FA, especially on email, banking, and social media accounts.");
                randomResponses[privacy].Add("You might want to review the security settings on your accounts.");
                
                examples[phishing].Add("SMS Phishing (Smishing) Example:\n\nSMS - 'FNB Alert: Your account has been locked due to unusual activity. Verify now: http://fnb-security-check.com' \n\nRed Flags: \n1) Claims of urgent security action. \n2) Fake link that mimics a real brand. \n3) Requests login or personal info.");
                examples[virus].Add("Real-World Example (Conceptual):\n\nName: Melissa Virus (1999)\nSpread by: Microsoft World document\nAction:\n1) Infected Word macros\n2) Sent itself to email contacts\n3) Caused mail servers to crash from overload.");
                examples[worm].Add("Example (Conceptual): Email Worm\n\nName: ILOVEYOU Worm (real-world worm from 2000)\n\nMethod:\n1) Arrived as an email with subject: 'ILOVEYOU'\n2) Attached file: 'LOVE-LETTER-FOR-YOU.txt.vbs'\n3) When opened, it:\na) Sent copies of itself to all contacts in Ooutlook.\nb) Overwrote image and music files.\nc) Crashed systems and slowed networks globally.\n\nHow it worked (simplified steps):\n1) User opens the .vbs file.\n2) Script accesses the contact list.\n3) Sends the same email + worm attachment to all contacts.\n4) Spreads rapidly without further action from the user.\n\nWhy it's dangerous:\n1) No user needed after first click.\n2) Consumes bandwidth, destroys files, spreads fast.");
                examples[trojan].Add("Real-World Example (Conceptual):\n\nName: GameOver Zeus Trojan\nDisguided as: A fake invoice, update, or game\nAction:\n1) Stole banking credentials\n2) Installed ransomware\n3) Used infected computers in a botnet.");
                examples[authentication].Add("Examples of 2FA:\n\n1) SMS Code: After entering your password, a code is sent to your phone via text.\n2) Authenticator App: You use apps like Google Authenticator or Authy to generate time-based one-time passwords (TOTP).\n3) Biometric Check: Face ID or fingerprint scan, especially on mobile devices.");
                examples[firewall].Add("Firewall Examples:\n\n1) Hardware Firewalls\n2) Software Firewalls\n3)Cloud-based Firewalls\n4) Next-Generation Firewalls");
                examples[phishingEmail].Add("Phishing Email Example: \n\nFrom: support@paypalsecurity-check.com\nSubject: Unusual Login Attempt Detected - Action Required\n\nBody: Dear Customer,\n\nWe detected an unusual login attempt from an unrecognized device.\n\nFor your protection, your account has been temporarily locked.\n\nTo restore full access, please verify your account by clicking the link below:\n\nVerify Account Now\n\nIf you do not verify within 24 hours, your account will be permanently suspended.\n\nThank you,\nPayPal Security Team\n\nRed Flags:\n1) Urgency and fear tactics ('permanently suspended').\n2) Fake domain that looks like a real one (e.g., paypal-security-check.com).\n3) Grammatical issues or inconsistent branding.\n4) Requests for login or sensitive information through a link.");
                examples[ciaTriad].Add("Confidentiality example: A company uses encryption and multi-factor authentication to protect customer credit card details from hackers.\n\nIntegrity example: A medical records system uses digital signatures to make sure patient files haven't altered without permission.\n\nAvailabilty example: A bank uses backup servers and load balancing so customers can access online banking even during high traffic or technical failure.");
                examples[privacy].Add("Keeping your medical records confidential - When you visit a doctor, your health information (like diagnoses, prescriptions, and test results) is protected by privacy laws (such as POPIA in South Africa or HIPAA in the US). Only authorized people, like your doctor or pharmacist, are allowed to access it. This ensures your personal health data isn't shared without your consent.");

                extraInfo[phishing].Add("Its main purpose is to steal sensitive by tricking users into clicking fake links or filing out fake forms.");
                extraInfo[virus].Add("Its primary objectives is to inject and damage files or systems, often spreading to other devices through infected files or media.");
                extraInfo[worm].Add("Its main use is to self-replicate and spread across networks, usually to cause disruption, consume bandwidth, or deliver payloads like malware.");
                extraInfo[trojan].Add("Its primary purpose is to secretly gain unauthorized access to a system, steal sensitive information, or cause harm, while evading detection by security measures.");
                extraInfo[authentication].Add("Its primary function is to add an extra layer of security beyond just a password, making it much harder for attackers to access accounts even if the password is stolen.");
                extraInfo[firewall].Add("Its primary purpose is to protect a computer or network from unauthorized access, malware and cyberattacks.");
                extraInfo[phishingEmail].Add("It tricks the recipient into revealing sensitive information.");
                extraInfo[ciaTriad].Add("The CIA triad protects sensitve information of the organization and maintains the trust of the organizations customers, partners, and stakeholders.");
                extraInfo[privacy].Add("It's a crucial part of staying safe online.");

                sentimentResponse[scam].Add("It's completely understandable to feel that way. Scammers can be very convincing. Let me share some tips to help you stay safe.");
                sentimentResponse[phishing].Add("That's a smart thing to be cautious about. Phishing is one of the most common and dangerous online threats. Here are tips on how to protect yourself.");
                sentimentResponse[virus].Add("That's completely understadable. Viruses can cause serious damage, from stealing personal info to crashing your system. Tips on how to protect yourself well.");
                sentimentResponse[worm].Add("It's good that you're thinking about worms. They're a serious type of malware that spreads without you doing anything. Let me share you some tips to help you stay safe.");
                sentimentResponse[trojan].Add("You're right to be concerned. Trojan are one of the sneakiest types of malware because they often look like safe or useful programs but secretly do harm once installed. Tips on how to protect yourself from trojans.");
                sentimentResponse[phishingEmail].Add("That's a very vaild concern. Phishing emails are one of the most common ways hackers trick people into giving up passwords, banking info, or installing malware. Tips on how to stay safe.");

                curiousResponse[scam].Add("That's a smart thing to explore. Understanding how online scams work is the best way to avoid falling for them. Types of Online Scams are Phishing, Romance scams, Investment scams, Tech support scams and online shopping scams.");
                curiousResponse[phishing].Add("Great because phishing is one of the most important online threats to understand. It's a type of scam where attackers try to trick you into revealing sensitive information like passwords, credit card numbers, or login details. Common types of Phishing are Email phishing, Spear phishing, Smishing and Vishing");
                curiousResponse[virus].Add("Being curious about viruses is a smart step toward protecting your devices and data. The most common viruses are File Infector Virus, Macro Virus, Boot Sector Virus, Web Scripting Virus and Resident Virus.");
                curiousResponse[worm].Add("Great because worms are a fascinating and dangerous type of malware. Notorious Worms in History are ILOVEYOU, WannaCry and Stuxnet.");
                curiousResponse[trojan].Add("Interesting because trojans are one of the most deceptive and dangerous types of malware. Common types of Trojans are Backdoor Trojan, Downloader Trojan, Banking Trojan, Spyware Trojan and Ransom Trojan.");
                curiousResponse[phishing].Add("That's good because phishing emails are a major security threat, understanding them is key to protecting yourself online.");

                while (!answer.Equals("exit"))
                {
                    if (answer.Contains("how are you"))
                    {
                        HowAreYouResponse(answer);
                    }
                    else if (answer.Contains("purpose"))
                    {
                        PurposeResponse(answer);
                    }
                    else if (answer.Contains("ask"))
                    {
                        UserQuestions(response);
                    }
                    else if (answer.Contains("password") || answer.Contains("safety"))
                    {
                        PasswordSafetyResponse(answer);
                    }
                    else if (answer.Contains("scam"))
                    {
                        sentimentDetection(curiousResponse, sentimentResponse, scam, answer);
                        ScamResponse(answer);
                    }
                    else if (answer.Contains("phishing"))
                    {
                        sentimentDetection(curiousResponse, sentimentResponse, phishing, answer);
                        Responses(answer, randomResponses, examples, extraInfo, phishing);
                    }
                    else if (answer.Contains("virus"))
                    {
                        sentimentDetection(curiousResponse, sentimentResponse, virus, answer);
                        Responses(answer, randomResponses, examples, extraInfo, virus);
                    }
                    else if (answer.Contains("worm"))
                    {
                        sentimentDetection(curiousResponse, sentimentResponse, worm, answer);
                        Responses(answer, randomResponses, examples, extraInfo, worm);
                    }
                    else if (answer.Contains("trojan"))
                    {
                        sentimentDetection(curiousResponse, sentimentResponse, trojan, answer);
                        Responses(answer, randomResponses, examples, extraInfo, trojan);
                    }
                    else if (answer.Contains("two-factor authentication"))
                    {
                        Responses(answer, randomResponses, examples, extraInfo, authentication);
                    }
                    else if (answer.Contains("firewall"))
                    {
                        Responses(answer, randomResponses, examples, extraInfo, firewall);
                    }
                    else if (answer.Contains("phishing email"))
                    {
                        sentimentDetection(curiousResponse, sentimentResponse, phishingEmail, answer);
                        Responses(answer, randomResponses, examples, extraInfo, phishingEmail);
                    }
                    else if (answer.Contains("cia triad"))
                    {
                        Responses(answer, randomResponses, examples, extraInfo, ciaTriad);
                    }
                    else if (answer.Contains("privacy"))
                    {
                        Responses(answer, randomResponses, examples, extraInfo, privacy);
                    }
                    Delay(1000);
                    TypeEffect($"\n\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                    Console.ResetColor();
                    answer = Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Delay(1000);
                TypeEffect($"{chatBotName}: {ex.Message}", 50);
            }
        }

        // This method creates the delay effect 
        private static void Delay(int milliseconds)
        {
            DateTime start = DateTime.Now;
            while ((DateTime.Now - start).TotalMilliseconds < milliseconds) ;
        }

        // This method creates a typing effect
        private static void TypeEffect(string text, int delay)
        {
            foreach (char c in text)
            { 
                Console.Write(c);
                Thread.Sleep(delay);
            }
        }

        // This method is where the chatbot responds to the users question "How are you"
        private void HowAreYouResponse(string answer)
        {
            Delay(1000);
            Console.ForegroundColor = ConsoleColor.Red;
            TypeEffect($"{chatBotName}: I'm feeling good even though i'm a chatbot with no feelings whatsoever, how are you feeling?\n{userName}: ", 50);
            Console.ResetColor();
            answer = Console.ReadLine();

            if (answer.Contains("good") || answer.Contains("great") || answer.Contains("alright") || answer.Contains("okay") || answer.Contains("fine") || answer.Contains("sharp") || answer.Contains("calm") || answer.Contains("relax"))
            {
                Delay(1000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: That's good to hear.", 50);
                Delay(1000);
                TypeEffect($"\n{chatBotName}: Do you have any other questions you would like to ask, if not type exit.\n{userName}: ", 50);
                Console.ResetColor();
                answer = Console.ReadLine();
            }
            else
            {
                Delay(1000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: Don't worry it's gonna be alright because tommorrow is another day:)", 50);
            }
        }

        // This method is where the chatbot explains its purpose to the user
        private void PurposeResponse(string answer)
        {
            Delay(1000);
            Console.ForegroundColor = ConsoleColor.Red;
            TypeEffect($"\n{chatBotName}: My purpose is to provide you with information regarding cybersecurity to help you better understand how to protect yourself from unwanted threats or anything that will harm your personal data or devices.", 50);
        }

        // This method is where the chatbot proposes questions that the user can ask
        private void UserQuestions(string response)
        {
            Delay(1000);
            Console.ForegroundColor = ConsoleColor.Red;
            TypeEffect($"{chatBotName}: You can ask anything that is cybersecurity related like password safety, phishing and safe browsing. You can choose 1 topic. \n{userName}: ", 50);
            Console.ResetColor();
            response = Console.ReadLine();
            Console.WriteLine();

            if (response.Contains("safety"))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}:\n\nPassword Safety " +
                    $"\n----------------\n" +
                    "Password safety refers to the practices and measures taken to protect passwords from unauthorized access, use, or compromise. " +
                    "Here are some key aspects of password safety:" +
                    "\n\nBEST PRACTICE FOR PASSWORD SAFETY" +
                    "\nUse strong and unique passwords: Use a combination of uppercase and lowercase letters, numbers, and special characters to create a strong password. " +
                    "Avoid using easily guessable information such as your name, birthdate, or common words." +
                    "\n\nPASSWORD SAFETY TIPS" +
                    "\nDon't share your passwords: Avoid sharing your passwords with " +
                    "others, including friends and family members." +
                    "\n\nPASSWORD SAFETY TOOLS" +
                    "\nTwo-factor authetication apps: Consider using a 2FA app, such as " +
                    "Google Authenticator or Authy, to generate time-based one-time passwords(TOTPs) for your accounts.\n", 10);
            }
            else if (response.Contains("phishing"))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}:\n\nPhishing" +
                    "\n---------\n" +
                    "Phishing is a type of cybercrime where attackers use fraudulent emails, " +
                    "texts, or messages to trick victims into revealing sensitive information, such as passwords, " +
                    "credit card numbers, or other personal data. " +
                    "\n\nTYPES OF PHISHING ATTACKS" +
                    "\nEmail Phishing: The most common type of phishing attack, where attackers send fake emails " +
                    "that appear to be from a legitimate source, such as a bank or online retailer." +
                    "\nSpear Phishing: A targeted phishing attack where attackers focus on a specific individual " +
                    "or group, often using personalized information to make the attack more convincing." +
                    "\n\nPHISHING TECHNIQUES" +
                    "\nSpoofing: Attackers create fake emails or websites that appear to be from a " +
                    "legitimate source." +
                    "\nBaiting: Attackers offer victims a tempting offer or reward in exchange for sensitive information." +
                    "\n\nHOW TO PROTECT YOURSELF FROM PHISHING ATTACKS" +
                    "\nBe cautius of suspicious emails or messages: If an email or message looks suspicious or asks for " +
                    "sensitive information, do not respond or click on any links." +
                    "\n\nWHAT TO DO IF YOU FALL VICTIM TO A PHISHING ATTACK" +
                    "\nChange your passwords: Immediately change your passwords for all accounts that may have been compromised.\n", 10);
            }
            else if (response.Contains("safe browsing"))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}:\n\nSafe Browsing" +
                    "\n--------------\n" +
                    "Safe browsing refers to the practice of using the internet in a way that protects your " +
                    "personal information, devices, and online idenity from potential threats and risks. Here are some " +
                    "key aspects of safe browsing: " +
                    "\n\nSAFE BROWSING PRACTICES" +
                    "\nUse a secure connection: Make sure the websites you visit use HTTPS(Hypertext Transfer Protocol Secure) " +
                    "instead of HTTP.This ensures that the data you exchange with the website is encrypted." +
                    "\nKeep your browser and software up to date: Regularly update your browser, operating system, and " +
                    "other software to ensureyou have the latest security patches and features." +
                    "\n\nSAFE BROWSING TOOLS" +
                    "\nBrowser extensions: Use browser extensions like uBlock Origin, HTTPS Everywhere, and LastPass " +
                    "to enhance your online security and privacy." +
                    "\n\nSAFE BROWSING TIPS" +
                    "\nBe aware of phishing scams: Be cautious of emails or messages that ask for personal information " +
                    "or direct you to suspicious websites.\n", 10);
            }
            else
            {
                Delay(1000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: I didn't quite understand that. Could you rephrase?\n{userName}: ", 50);
                Console.ResetColor();
                response = Console.ReadLine();
            }
        }

        // This method is where the chatbot responds to the user about password safety
        private void PasswordSafetyResponse(string answer)
        {
            Delay(2000);
            Console.ForegroundColor = ConsoleColor.Red;
            TypeEffect($"{chatBotName}: Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords.", 50);
        }

        // This method is where the chatbot responds to the user about online scamming
        private void ScamResponse(string answer)
        {
            Delay(2000);
            Console.ForegroundColor = ConsoleColor.Red;
            TypeEffect($"\n{chatBotName}: Be wary of suspicious emails, verify the sender's identity, watch out for spelling and grammar mistakes, don't click on suspicious links and try to use two-factor authentication.", 50);
        }

        // This method shuffles the values in a list
        private void ShuffleList(Dictionary<string, List<string>> randomResponses, string topic)
        {
            Random rnd = new Random();
            for (int i = randomResponses[topic].Count - 1; i >= 0; i--)
            {
                int j = rnd.Next(i + 1);

                var temp = randomResponses[topic][i];
                randomResponses[topic][i] = randomResponses[topic][j];
                randomResponses[topic][j] = temp;
            }
        }

        // This method is where the chatbot responds to the user in a professional manner including memory and recall
        private void Responses(string answer, Dictionary<string, List<string>> randomResponses, Dictionary<string, List<string>> examples, Dictionary<string, List<string>> extraInfo, string topic)
        {
            if (answer.Contains("interest") || answer.Contains("like") || answer.Contains("love"))
            {
                favouriteTopic = topic;
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"\n{chatBotName}: Great! I'll remember that you're interested in {favouriteTopic}. {extraInfo[topic].First()}", 50);
            }

            Delay(2000);
            Console.ForegroundColor = ConsoleColor.Red;
            TypeEffect($"\n{chatBotName}: {randomResponses[topic].First()}", 50);
            ShuffleList(randomResponses, topic);

            TypeEffect($"\n\n{chatBotName}: Would you like more {topic} tips or an example of a {topic}? If not, you can always type exit :)\n{userName}: ", 50);
            Console.ResetColor();
            answer = Console.ReadLine();

            if (answer.Contains("tip"))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: {randomResponses[topic].First()}", 50);
                ShuffleList(randomResponses, topic);
            }
            else if (answer.Contains("example") || answer.Contains(topic))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: {examples[topic].First()}", 50);
            }
            else
            {
                Delay(1000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"{chatBotName}: I'm not sure I quite understand. Can you try rephrasing?\n{userName}: ", 50);
                Console.ResetColor();
                answer = Console.ReadLine();
            }

            if (favouriteTopic.Equals(topic))
            {
                Delay(1000);
                TypeEffect($"\n\n{chatBotName}: As someone interested in {favouriteTopic}, {randomResponses[topic].First()}", 50);
                ShuffleList(randomResponses, topic);
            }
        }

        // This method is where the chatbot will detect sentiment in the user's text
        private void sentimentDetection(Dictionary<string, List<string>> curiousResponse, Dictionary<string, List<string>> sentimentResponse, string topic, string answer)
        {
            if (answer.Contains("worried") || answer.Contains("frustrated"))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"\n{chatBotName}: {sentimentResponse[topic].First()}", 50);
            }
            else if (answer.Contains("curious"))
            {
                Delay(2000);
                Console.ForegroundColor = ConsoleColor.Red;
                TypeEffect($"\n{chatBotName}: {curiousResponse[topic].First()}", 50);
            }
        }
    }
}
