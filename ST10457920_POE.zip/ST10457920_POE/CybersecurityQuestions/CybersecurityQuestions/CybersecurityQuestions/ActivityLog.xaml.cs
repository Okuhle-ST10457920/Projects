﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CybersecurityQuestions
{
    /// <summary>
    /// Interaction logic for ActivityLog.xaml
    /// </summary>
    public partial class ActivityLog : Window
    {
        public List<string> activityLog = new List<string>();

        public ActivityLog()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string text = answerTxt.Text.ToLower();

            if (text.Equals("show activity log") || text.Equals("what have you done for me?"))
            {
                for (int i = 0; i < 5; i++)
                {
                    MessageBox.Show($"{1}. {activityLog[i]}", "Activity Log", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
    }
}
