﻿using System.Windows;

namespace CybersecurityQuestions
{
    /// <summary>
    /// Interaction logic for CybersecurityAwareness.xaml
    /// </summary>
    public partial class CybersecurityAwareness : Window
    {
        int userScore, questionsAnswered;
        private string firstOption = "", secOption = "", thirdOption = "", fourthOption = "";
        private string fourthAnswer = "", fifthAnswer = "", sixthAnswer = "", seventhAnswer = "", eighthAnswer = "", ninthAnswer = "", tenthAnswer = "";

        public CybersecurityAwareness()
        {
            InitializeComponent();
        }

        private void firstQuestionSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (replyAnswer.IsChecked == true & !firstOption.Equals("1a") & !secOption.Equals("1b") & !thirdOption.Equals("1c") & !fourthOption.Equals("1d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'Report the email as phishing'. \nExplanation: Reporting phishing emails helps prevent scams.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                firstOption = "1a";
                questionsAnswered += 1;
            }
            else if (deleteAnswer.IsChecked == true & !firstOption.Equals("1a") & !secOption.Equals("1b") & !thirdOption.Equals("1c") & !fourthOption.Equals("1d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'Report the email as phishing'. \nExplanation: Reporting phishing emails helps prevent scams.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                secOption = "1b";
                questionsAnswered += 1;
            }
            else if (reportAnswer.IsChecked == true & !firstOption.Equals("1a") & !secOption.Equals("1b") & !thirdOption.Equals("1c") & !fourthOption.Equals("1d"))
            {
                MessageBox.Show("Correct! Reporting phishing emails helps prevent scams.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                thirdOption = "1c";
                userScore += 1;
                questionsAnswered += 1;
            }
            else if (ignoreAnswer.IsChecked == true & !firstOption.Equals("1a") & !secOption.Equals("1b") & !thirdOption.Equals("1c") & !fourthOption.Equals("1d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'Report the email as phishing'. \nExplanation: Reporting phishing emails helps prevent scams.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                fourthOption = "1d";
                questionsAnswered += 1;
            }
            else if (firstOption.Equals("1a") || secOption.Equals("1b") || thirdOption.Equals("1c") || fourthOption.Equals("1d"))
            {
                MessageBox.Show("You have already answered this question.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                return;
            }
        }

        private void secondQuestionSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (scanAnswer.IsChecked == true & !firstOption.Equals("2a") & !secOption.Equals("2b") & !thirdOption.Equals("2c") & !fourthOption.Equals("2d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'To control and monitor incoming and outgoing network traffic based on security rules'. \nExplanation: A firewall filters traffic between trusted and untrusted networks based on configured rules, helping prevent unauthorized access.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                firstOption = "2a";
                questionsAnswered += 1;
            }
            else if (encryptAnswer.IsChecked == true & !firstOption.Equals("2a") & !secOption.Equals("2b") & !thirdOption.Equals("2c") & !fourthOption.Equals("2d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'To control and monitor incoming and outgoing network traffic based on security rules'. \nExplanation: A firewall filters traffic between trusted and untrusted networks based on configured rules, helping prevent unauthorized access.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                secOption = "2b";
                questionsAnswered += 1;
            }
            else if (controlAnswer.IsChecked == true & !firstOption.Equals("2a") & !secOption.Equals("2b") & !thirdOption.Equals("2c") & !fourthOption.Equals("2d"))
            {
                MessageBox.Show("Correct! A firewall filters traffic between trusted and untrusted networks based on configured rules, helping prevent unauthorized access.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                thirdOption = "2c";
                userScore += 1;
                questionsAnswered += 1;
            }
            else if (blockAnswer.IsChecked == true & !firstOption.Equals("2a") & !secOption.Equals("2b") & !thirdOption.Equals("2c") & !fourthOption.Equals("2d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'To control and monitor incoming and outgoing network traffic based on security rules'. \nExplanation: A firewall filters traffic between trusted and untrusted networks based on configured rules, helping prevent unauthorized access.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                fourthOption = "2d";
                questionsAnswered += 1;
            }
            else if (firstOption.Equals("2a") || secOption.Equals("2b") || thirdOption.Equals("2c") || fourthOption.Equals("2d"))
            {
                MessageBox.Show("You have already answered this question.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                return;
            }
        }

        private void thirdQuestionSubmit_Click(object sender, RoutedEventArgs e)
        {
            if (malwareAnswer.IsChecked == true & !firstOption.Equals("3a") & !secOption.Equals("3b") & !thirdOption.Equals("3c") & !fourthOption.Equals("3d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'A deceptive attempt to obtain sensitive information by pretending to be a trustworthy source'. \nExplanation: Phishing involves tricking users into revealing confidential information like passwords or credit card numbers by pretending to be a legitimate entity (e.g., bank, email service).", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                firstOption = "3a";
                questionsAnswered += 1;
            }
            else if (unauthorizedAnswer.IsChecked == true & !firstOption.Equals("3a") & !secOption.Equals("3b") & !thirdOption.Equals("3c") & !fourthOption.Equals("3d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'A deceptive attempt to obtain sensitive information by pretending to be a trustworthy source'. \nExplanation: Phishing involves tricking users into revealing confidential information like passwords or credit card numbers by pretending to be a legitimate entity (e.g., bank, email service).", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                secOption = "3b";
                questionsAnswered += 1;
            }
            else if (attackAnswer.IsChecked == true & !firstOption.Equals("3a") & !secOption.Equals("3b") & !thirdOption.Equals("3c") & !fourthOption.Equals("3d"))
            {
                MessageBox.Show("Wrong Answer, Sorry :( \nThe correct answer is 'A deceptive attempt to obtain sensitive information by pretending to be a trustworthy source'. \nExplanation: Phishing involves tricking users into revealing confidential information like passwords or credit card numbers by pretending to be a legitimate entity (e.g., bank, email service).", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                thirdOption = "3c";
                questionsAnswered += 1;
            }
            else if (deceptiveAnswer.IsChecked == true & !firstOption.Equals("3a") & !secOption.Equals("3b") & !thirdOption.Equals("3c") & !fourthOption.Equals("3d"))
            {
                MessageBox.Show("Correct! Phishing involves tricking users into revealing confidential information like passwords or credit card numbers by pretending to be a legitimate entity (e.g., bank, email service).", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                fourthOption = "3d";
                userScore += 1;
                questionsAnswered += 1;
            }
            else if (firstOption.Equals("3a") || secOption.Equals("3b") || thirdOption.Equals("3c") || fourthOption.Equals("3d"))
            {
                MessageBox.Show("You have already answered this question.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                return;
            }
        }

        private void nextPage_Click(object sender, RoutedEventArgs e)
        {
            ActivityLog activityLog = new ActivityLog();
            activityLog.activityLog.Add($"Quiz started - {questionsAnswered} questions answered.");
            activityLog.activityLog.Add($"Quiz ended - {userScore} questions answered correctly.");
            activityLog.Show();
            this.Close();
        }

        private void submitQuestionFour_Click(object sender, RoutedEventArgs e)
        {
            string questionFourAnswer = QFourTxt.Text.ToLower();

            if (questionFourAnswer.Contains("yes") & !fourthAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: If one website gets hacked and your password is leaked, attackers can try the same credentials on other sites (called 'credential stuffing'). Using unique passwords for each site helps prevent this.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                fourthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionFourAnswer.Contains("no") & !fourthAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: If one website gets hacked and your password is leaked, attackers can try the same credentials on other sites (called 'credential stuffing'). Using unique passwords for each site helps prevent this.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                fourthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (fourthAnswer.Equals("answered"))
            {
                MessageBox.Show("You have already answered this question.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void submitQuestionFive_Click(object sender, RoutedEventArgs e)
        {
            string questionFiveAnswer = QFiveTxt.Text.ToLower();

            if (questionFiveAnswer.Contains("no") & !fifthAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: Public Wi-Fi networks are often unsecured and can be monitored by hackers using tools like packet sniffers or man-in-middle attacks. It's risky to log in to sensitive accounts without a VPN.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                fifthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionFiveAnswer.Contains("yes") & !fifthAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: Public Wi-Fi networks are often unsecured and can be monitored by hackers using tools like packet sniffers or man-in-middle attacks. It's risky to log in to sensitive accounts without a VPN.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                fifthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (fifthAnswer.Equals("answered"))
            {
                MessageBox.Show("You have already answered this question.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void submitQuestionSix_Click(object sender, RoutedEventArgs e)
        {
            string questionSixAnswer = QSixTxt.Text.ToLower();

            if (questionSixAnswer.Contains("no") & !sixthAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: While antivirus software is useful, it cannot catch every threat - especially advanced or zero-day exploits, rootkits, or some types of ransomware. It's one layer in a larger security strategy.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                sixthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionSixAnswer.Contains("yes") & !sixthAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: While antivirus software is useful, it cannot catch every threat - especially advanced or zero-day exploits, rootkits, or some types of ransomware. It's one layer in a larger security strategy.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                sixthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (sixthAnswer.Equals("answered"))
            {
                MessageBox.Show("You have already answered this question.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void submitQuestionSeven_Click(object sender, RoutedEventArgs e)
        {
            string questionSevenAnswer = QSevenTxt.Text.ToLower();

            if (questionSevenAnswer.Contains("yes") & !seventhAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: 2FA adds an extra layer of protection by requiring something you know (password) and something you have (like a phone or security token), making it much harder for attackers to access your account.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                seventhAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionSevenAnswer.Contains("no") & !seventhAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: 2FA adds an extra layer of protection by requiring something you know (password) and something you have (like a phone or security token), making it much harder for attackers to access your account.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                seventhAnswer = "answered";
                questionsAnswered += 1;
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void submitQuestionEight_Click(object sender, RoutedEventArgs e)
        {
            string questionEightAnswer = QEightTxt.Text.ToLower();

            if (questionEightAnswer.Contains("yes") & !eighthAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: Software updates often include security patches for known vulnerabilities. Delaying updates can leave your system exposed to exploits targeting outdated versions.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                eighthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionEightAnswer.Contains("no") & !eighthAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: Software updates often include security patches for known vulnerabilities. Delaying updates can leave your system exposed to exploits targeting outdated versions.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                eighthAnswer = "answered";
                questionsAnswered += 1;
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void submitQuestionNine_Click(object sender, RoutedEventArgs e)
        {
            string questionNineAnswer = QNineTxt.Text.ToLower();

            if (questionNineAnswer.Contains("no") & !ninthAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: A firewall is designed to filter and control network traffic based on security rules. It does not speed up internet but helps prevent unauthorized access and data breaches.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                ninthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionNineAnswer.Contains("yes") & !ninthAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: A firewall is designed to filter and control network traffic based on security rules. It does not speed up internet but helps prevent unauthorized access and data breaches.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                ninthAnswer = "answered";
                questionsAnswered += 1;
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void submitQuestionTen_Click(object sender, RoutedEventArgs e)
        {
            string questionTenAnswer = QTenTxt.Text.ToLower();

            if (questionTenAnswer.Contains("yes") & !tenthAnswer.Equals("answered"))
            {
                MessageBox.Show("Correct! \nExplanation: Email attachments can contain malicious files such as viruses, ransomware, or spyware. Opening them - especially from unknown or suspicious senders - can infect your system and compromise data security.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                userScore += 1;
                tenthAnswer = "answered";
                questionsAnswered += 1;
            }
            else if (questionTenAnswer.Contains("no") & !tenthAnswer.Equals("answered"))
            {
                MessageBox.Show("Wrong answer! Sorry :( \nExplanation: Email attachments can contain malicious files such as viruses, ransomware, or spyware. Opening them - especially from unknown or suspicious senders - can infect your system and compromise data security.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
                tenthAnswer = "answered";
                questionsAnswered += 1;
            }
            else
            {
                MessageBox.Show("Please answer the question first.", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void viewScore_Click(object sender, RoutedEventArgs e)
        {
            if (userScore > 5)
            {
                MessageBox.Show($"Score: {userScore} \nGreat job! You're a cybersecurity pro!", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show($"Score: {userScore} \nKeep learning to stay safe online!", "Cybersecurity Quiz", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            resetAnswers();
        }

        private void resetAnswers()
        {
            replyAnswer.IsChecked = false;
            deleteAnswer.IsChecked = false;
            reportAnswer.IsChecked = false;
            ignoreAnswer.IsChecked = false;
            scanAnswer.IsChecked = false;
            encryptAnswer.IsChecked= false;
            controlAnswer.IsChecked = false;
            blockAnswer.IsChecked = false;
            malwareAnswer.IsChecked = false;
            unauthorizedAnswer.IsChecked = false;
            attackAnswer.IsChecked = false;
            deceptiveAnswer.IsChecked = false;
            QFourTxt.Text = null;
            QFiveTxt.Text = null;
            QSixTxt.Text = null;
            QSevenTxt.Text = null;
            QEightTxt.Text = null;
            QNineTxt.Text = null;
            QTenTxt.Text = null;
            userScore = 0;
        }
    }
}
