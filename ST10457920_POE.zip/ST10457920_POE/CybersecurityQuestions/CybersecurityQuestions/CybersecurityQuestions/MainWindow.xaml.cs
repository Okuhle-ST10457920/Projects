﻿using System.Windows;
using System.Windows.Controls;

namespace CybersecurityQuestions;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    List<string> title = new List<string>();
    List<string> titleDescription = new List<string>();
    List<string> reminder = new List<string>();
    List<string> titleMarkedAsCompleted = new List<string>();
    List<string> titleDescriptionMarkedAsCompleted = new List<string>();
    List<string> reminderMarkedAsCompleted = new List<string>();
    public int userScore = 0;

    public MainWindow()
    {
        InitializeComponent();
    }

    private void validateTaskSelected(object sender, RoutedEventArgs e)
    {
        string taskDescription = "";

        if (isCheckBoxValid(twoFactorCheckBox) & isCheckBoxValid(reviewAccountCheckBox) != true)
        {
            taskDescription = "Set up 2FA to ensure your data remains protected from unauthorized access";
            MessageBox.Show($"Task added with the description '{taskDescription}'", "Task Description", MessageBoxButton.OK, MessageBoxImage.Information);
            title.Add("Enable two-Factor Authentication");
            titleDescription.Add(taskDescription);
        }
        else if (isCheckBoxValid(reviewAccountCheckBox) & isCheckBoxValid(twoFactorCheckBox) != true)
        {
            taskDescription = "Review account privacy settings to ensure your data is protected.";
            MessageBox.Show($"Task added with the description '{taskDescription}'", "Task Description", MessageBoxButton.OK, MessageBoxImage.Information);
            title.Add("Review account privacy settings");
            titleDescription.Add(taskDescription);
        }
        else
        {
            return;
        }
    }

    private void validateComboBox(object sender, SelectionChangedEventArgs e)
    {
        string selectedItem = reminderComboBox.SelectedItem.ToString();

        if (selectedItem.Equals("Remind me tomorrow"))
        {
            MessageBox.Show("Got it! I'll remind you tomorrow.", "Reminder", MessageBoxButton.OK, MessageBoxImage.Information);
            reminder.Add("tomorrow");
        }
        else if (selectedItem.Equals("Remind me in 3 days"))
        {
            MessageBox.Show("Got it! I'll remind you in 3 days.", "Reminder", MessageBoxButton.OK, MessageBoxImage.Information);
            reminder.Add("3 days");
        }
        else if (selectedItem.Equals("Remind me in 5 days"))
        {
            MessageBox.Show("Got it! I'll remind you in 5 days.", "Reminder", MessageBoxButton.OK, MessageBoxImage.Information);
            reminder.Add("5 days");
        }
        else if (selectedItem.Equals("Remind me in 1 week"))
        {
            MessageBox.Show("Got it! I'll remind you in 1 week.", "Reminder", MessageBoxButton.OK, MessageBoxImage.Information);
            reminder.Add("1 week");
        }
        else if (selectedItem.Equals("Remind me in 2 weeks"))
        {
            MessageBox.Show("Got it! I'll remind you in 2 weeks.", "Reminder", MessageBoxButton.OK, MessageBoxImage.Information);
            reminder.Add("2 weeks");
        }
        else
        {
            MessageBox.Show("Please select an option.");
            return;
        }
        MainAddActivityLog();
    }

    private void MainAddActivityLog()
    {
        ActivityLog activityLog = new ActivityLog();
        int lastIndex = title.Count - 1;
        activityLog.activityLog.Add($"Task added: '{title[lastIndex]}' (Reminder set for {reminder[lastIndex]} from now).");
    }

    private void view_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            for (int i = 0; i < title.Count; i++)
            {
                MessageBox.Show($"Title: {title[i]} \nTask description: {titleDescription[i]} \nReminder timeframe: {reminder[i]}", "Tasks", MessageBoxButton.OKCancel, MessageBoxImage.Information);
            }
        }
        catch (Exception)
        {
            MessageBox.Show("Please select a title description with a corresponding reminder.", "Tasks", MessageBoxButton.OKCancel, MessageBoxImage.Information);
        }
    }

    private void delete_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            for (int i = 0; i < title.Count; i++)
            {
                var result = MessageBox.Show($"Title: {title[i]} \nTask description: {titleDescription[i]} \nReminder timeframe: {reminder[i]}", "Delete Task", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    title.RemoveAt(i);
                    titleDescription.RemoveAt(i);
                    reminder.RemoveAt(i);
                    MessageBox.Show("Task deleted.", "Delete Task", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
        catch (Exception)
        {
            MessageBox.Show("Please select a title description with a corresponding reminder.", "Tasks", MessageBoxButton.OKCancel, MessageBoxImage.Information);
        }
    }

    private void mark_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            for (int i = 0; i < title.Count; i++)
            {
                var result = MessageBox.Show($"Title: {title[i]} \nTask description: {titleDescription[i]} \nReminder timeframe: {reminder[i]}", "Mark Task", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    titleMarkedAsCompleted.Add(title[i]);
                    titleDescriptionMarkedAsCompleted.Add(titleDescription[i]);
                    reminderMarkedAsCompleted.Add(reminder[i]);
                    title.RemoveAt(i);
                    titleDescription.RemoveAt(i);
                    reminder.RemoveAt(i);
                    MessageBox.Show("Task marked as completed.", "Mark Task", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }
        catch (Exception)
        {
            MessageBox.Show("Please select a title description with a corresponding reminder.", "Tasks", MessageBoxButton.OKCancel, MessageBoxImage.Information);
        }
    }

    private void comboBoxAddItems(object sender, RoutedEventArgs e)
    {
        reminderComboBox.Items.Add("Remind me tomorrow");
        reminderComboBox.Items.Add("Remind me in 3 days");
        reminderComboBox.Items.Add("Remind me in 5 days");
        reminderComboBox.Items.Add("Remind me in 1 week");
        reminderComboBox.Items.Add("Remind me in 2 weeks");
    }

    private bool isCheckBoxValid(CheckBox checkBox)
    {
        return checkBox.IsChecked == true;
    }

    private void nextPage_Click(object sender, RoutedEventArgs e)
    {
        CybersecurityAwareness cybersecurityAwareness = new CybersecurityAwareness();
        cybersecurityAwareness.Show();
        this.Close();
    }
}