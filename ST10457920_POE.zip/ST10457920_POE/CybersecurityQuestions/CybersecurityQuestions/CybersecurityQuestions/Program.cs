﻿using System.Runtime.InteropServices;
using System.Windows;

namespace CybersecurityQuestions
{
    public class Program
    {
        private static string answered = "";
        [DllImport("kernel32.dll")]
        static extern bool AllocConsole();
        [DllImport("kernel32.dll")]
        static extern bool FreeConsole();

        [STAThread]

        // This main method will call and run the methods in the Chatbot class
        public static void Main()
        {
            var result = MessageBox.Show("Do you want to meet the chatbot?", "Cybersecurity Awareness", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                AllocConsole();
                ChatBot chatBot = new ChatBot();
                chatBot.Voice_Greeting();
                chatBot.ASCII_Display();
                chatBot.Text_Greeting();
                chatBot.Response_System();
                FreeConsole();
                answered = "answered";
            }

            result = MessageBox.Show("Do you want to see the Cybersecurity awareness page?", "Cybersecurity Awareness", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                var app = new Application();
                var mainWindow = new MainWindow();
                app.Run(mainWindow);

                if (!answered.Equals("answered"))
                {
                    result = MessageBox.Show("Don't you want to meet the chatbot?", "Cybersecurity Awareness", MessageBoxButton.YesNo, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        AllocConsole();
                        ChatBot chatBot = new ChatBot();
                        chatBot.Voice_Greeting();
                        chatBot.ASCII_Display();
                        chatBot.Text_Greeting();
                        chatBot.Response_System();
                        FreeConsole();
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }
    }
}